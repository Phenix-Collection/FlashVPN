package com.mobvista.sdk.demo.view;

import com.mobvista.sdk.demo.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CommonTitleLayout extends LinearLayout {
	private View view;
	private TextView mTvTitle;

	@SuppressLint("NewApi")
	public CommonTitleLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initLayout();
	}

	public CommonTitleLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CommonTitleLayout(Context context) {
		this(context, null);
	}

	private void initLayout() {
		view = View.inflate(getContext(), R.layout.mobvista_demo_common_title_layout, this);
		mTvTitle = (TextView) view.findViewById(R.id.mobvista_demo_tv_title);
		mTvTitle.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				try {
					if (getContext() instanceof Activity) {
						((Activity) getContext()).finish();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
	}

	public void setTitleText(String titleName) {
		if (!TextUtils.isEmpty(titleName)) {
			mTvTitle.setText(titleName);
		}

	}
}
