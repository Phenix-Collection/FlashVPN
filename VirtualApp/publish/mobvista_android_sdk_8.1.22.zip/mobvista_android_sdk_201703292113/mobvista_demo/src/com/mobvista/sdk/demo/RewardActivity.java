package com.mobvista.sdk.demo;

import com.mobvista.msdk.out.MVRewardVideoHandler;
import com.mobvista.msdk.out.PermissionUtils;
import com.mobvista.msdk.out.RewardVideoListener;
import com.mobvista.msdk.videocommon.download.NetStateOnReceive;
import com.mobvista.sdk.demo.view.CommonTitleLayout;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class RewardActivity extends BaseActivity implements OnClickListener {
	private final static String TAG = "RewardActivity";
	private Button bt_load;
	private Button bt_show;
	private CommonTitleLayout mTitleLayout;
	private MVRewardVideoHandler mMvRewardVideoHandler;
	private ProgressBar mProgressBar;
	private boolean FLAG_PERMISSION_READ_WRITE_EXTERNALSTORAGE = false;
	private NetStateOnReceive mNetStateOnReceive;
	private Dialog mDialog;
	private String mRewardUnitId = "2163";
	private String mRewardId = "12817";
	private String mUserId = "123";

	@Override
	public int getResLayoutId() {
		return R.layout.mobvista_demo_atv_reward;
	}

	@Override
	public void initView() {
		bt_load = (Button) findViewById(R.id.bt_load);
		bt_show = (Button) findViewById(R.id.bt_show);
		mProgressBar = (ProgressBar) findViewById(R.id.mobvista_demo_progress);
		mTitleLayout = (CommonTitleLayout) findViewById(R.id.mobvista_demo_common_title_layout);

	}

	@Override
	public void initData() {
		initHandler();
		// apply the permission to load video
		PermissionUtils.requestPermission(this, PermissionUtils.CODE_WRITE_EXTERNAL_STORAGE, mPermissionGrant);

	}

	@Override
	public void setListener() {
		mTitleLayout.setTitleText("RewardVideo");
		bt_load.setOnClickListener(this);
		bt_show.setOnClickListener(this);
	}

	private void showLoadding() {
		mProgressBar.setVisibility(View.VISIBLE);
	}

	private void hideLoadding() {
		mProgressBar.setVisibility(View.GONE);
	}

	private void initHandler() {
		try {
			// Declare network status for downloading video
			if (mNetStateOnReceive == null) {
				mNetStateOnReceive = new NetStateOnReceive();
				IntentFilter filter = new IntentFilter();
				filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
				registerReceiver(mNetStateOnReceive, filter);
			}

			mMvRewardVideoHandler = new MVRewardVideoHandler(this, mRewardUnitId);
			mMvRewardVideoHandler.setRewardVideoListener(new RewardVideoListener() {

				@Override
				public void onVideoLoadSuccess() {
					Log.e(TAG, "onVideoLoadSuccess");
					hideLoadding();
					Toast.makeText(getApplicationContext(), "onVideoLoadSuccess()", Toast.LENGTH_SHORT).show();

				}

				@Override
				public void onVideoLoadFail() {
					Log.e(TAG, "onVideoLoadFail");
					hideLoadding();
					Toast.makeText(getApplicationContext(), "onVideoLoadFail()", 0).show();

				}

				@Override
				public void onShowFail(String errorMsg) {
					Log.e(TAG, "onShowFail=" + errorMsg);
					Toast.makeText(getApplicationContext(), "errorMsg:" + errorMsg, Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onAdShow() {
					Log.e(TAG, "onAdShow");
				}

				@Override
				public void onAdClose(boolean isCompleteView, String RewardName, float RewardAmout) {
					Log.e(TAG, "reward info :" + "RewardName:" + RewardName + "RewardAmout:" + RewardAmout);
					showDialog(RewardName, RewardAmout);
				}

				@Override
				public void onVideoAdClicked(String unitId) {
					Log.e(TAG, "onVideoAdClicked");
				}

			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_load:
			if (!FLAG_PERMISSION_READ_WRITE_EXTERNALSTORAGE) {
				PermissionUtils.requestPermission(this, PermissionUtils.CODE_WRITE_EXTERNAL_STORAGE, mPermissionGrant);

			} else {
				showLoadding();
				mMvRewardVideoHandler.load();
			}

			break;
		case R.id.bt_show:
			if (!FLAG_PERMISSION_READ_WRITE_EXTERNALSTORAGE) {
				PermissionUtils.requestPermission(this, PermissionUtils.CODE_WRITE_EXTERNAL_STORAGE, mPermissionGrant);

			} else {
				if (mMvRewardVideoHandler.isReady()) {
					mMvRewardVideoHandler.show(mRewardId, mUserId);
				}
			}

			break;
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		try {
			if (mDialog != null) {
				mDialog = null;
			}
			if (mNetStateOnReceive != null) {
				unregisterReceiver(mNetStateOnReceive);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showDialog(String RewardName, float RewardAmout) {
		mDialog = new Dialog(RewardActivity.this);
		View view = View.inflate(RewardActivity.this, R.layout.dialog_reward, null);
		TextView tvRewardName = (TextView) view.findViewById(R.id.tv_rewardName);
		TextView tvRewardAmout = (TextView) view.findViewById(R.id.tv_RewardAmout);
		tvRewardName.setText(RewardName + "");
		tvRewardAmout.setText(RewardAmout + "");
		mDialog.setContentView(view);
		mDialog.show();
	}

	private PermissionUtils.PermissionGrant mPermissionGrant = new PermissionUtils.PermissionGrant() {
		@Override
		public void onPermissionGranted(int requestCode) {
			switch (requestCode) {
			case PermissionUtils.CODE_WRITE_EXTERNAL_STORAGE:
				// Toast.makeText(RewardActivity.this, "Permission to apply successfully",
				// Toast.LENGTH_SHORT).show();
				FLAG_PERMISSION_READ_WRITE_EXTERNALSTORAGE = true;
				break;
			default:
				break;
			}
		}
	};

	@SuppressLint("Override")
	@Override
	public void onRequestPermissionsResult(final int requestCode, @NonNull String[] permissions,
			@NonNull int[] grantResults) {
		PermissionUtils.requestPermissionsResult(this, requestCode, permissions, grantResults, mPermissionGrant);
	}

}
