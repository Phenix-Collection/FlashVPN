package com.mobvista.sdk.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mobvista.msdk.MobVistaConstans;
import com.mobvista.msdk.MobVistaSDK;
import com.mobvista.msdk.out.Campaign;
import com.mobvista.msdk.out.Frame;
import com.mobvista.msdk.out.MobVistaSDKFactory;
import com.mobvista.msdk.out.MvNativeHandler;
import com.mobvista.msdk.out.PreloadListener;
import com.mobvista.msdk.out.MvNativeHandler.NativeAdListener;
import com.mobvista.msdk.out.MvNativeHandler.Template;
import com.mobvista.sdk.demo.util.ImageLoadTask;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Native display Banner style
 * 
 * @author
 *
 */
public class BannerActivity extends BaseActivity {

	private static final String TAG = BannerActivity.class.getName();
	public static final String UNIT_ID = "493";
	private RelativeLayout mRl_Root;
	private ImageView mIvIcon;
	private TextView mTvAppName;
	private TextView mTvAppDesc;
	private TextView mTvCta;
	private ProgressBar mProgressBar;
	private MvNativeHandler nativeHandle;

	@Override
	public int getResLayoutId() {
		return R.layout.mobvista_native_banner_activity;
	}

	@Override
	public void initData() {
		showLoadding();
		loadNative();
	}

	@Override
	public void setListener() {

	}

	public void showLoadding() {
		mProgressBar.setVisibility(View.VISIBLE);
		mRl_Root.setVisibility(View.GONE);
	}

	public void hideLoadding() {
		mProgressBar.setVisibility(View.GONE);
		mRl_Root.setVisibility(View.VISIBLE);
	}

	public void preloadNative() {
		MobVistaSDK sdk = MobVistaSDKFactory.getMobVistaSDK();
		Map<String, Object> preloadMap = new HashMap<String, Object>();
		preloadMap.put(MobVistaConstans.PROPERTIES_LAYOUT_TYPE, MobVistaConstans.LAYOUT_NATIVE);
		preloadMap.put(MobVistaConstans.PROPERTIES_UNIT_ID, UNIT_ID);
		List<Template> list = new ArrayList<Template>();
		list.add(new Template(MobVistaConstans.TEMPLATE_MULTIPLE_IMG, 1));
		preloadMap.put(MobVistaConstans.NATIVE_INFO, MvNativeHandler.getTemplateString(list));
		sdk.preload(preloadMap);

	}

	@Override
	public void initView() {
		mRl_Root = (RelativeLayout) findViewById(R.id.mobvista_banner_rl_root);
		mIvIcon = (ImageView) findViewById(R.id.mobvista_banner_iv_icon);
		mTvAppName = (TextView) findViewById(R.id.mobvista_banner_tv_title);
		mTvAppDesc = (TextView) findViewById(R.id.mobvista_banner_tv_app_desc);
		mTvCta = (TextView) findViewById(R.id.mobvista_banner_tv_cta);
		mProgressBar = (ProgressBar) findViewById(R.id.mobvista_banner_progress);
	}

	private void loadNative() {
		Map<String, Object> properties = MvNativeHandler.getNativeProperties(UNIT_ID);
		nativeHandle = new MvNativeHandler(properties, this);
		nativeHandle.addTemplate(new Template(MobVistaConstans.TEMPLATE_MULTIPLE_IMG, 1));
		nativeHandle.setAdListener(new NativeAdListener() {

			@Override
			public void onAdLoaded(List<Campaign> campaigns, int template) {
				hideLoadding();
				fillBannerLayout(campaigns);
				preloadNative();
			}

			@Override
			public void onAdLoadError(String message) {
				Log.e(TAG, "onAdLoadError:" + message);
			}

			@Override
			public void onAdFramesLoaded(List<Frame> list) {

			}

			@Override
			public void onAdClick(Campaign campaign) {
				Log.e(TAG, "onAdClick");
			}
		});
		nativeHandle.load();
	}

	protected void fillBannerLayout(List<Campaign> campaigns) {
		if (campaigns != null && campaigns.size() > 0) {
			Campaign campaign = campaigns.get(0);
			if (!TextUtils.isEmpty(campaign.getIconUrl())) {
				new ImageLoadTask(campaign.getIconUrl()) {

					@Override
					public void onRecived(Drawable result) {
						mIvIcon.setImageDrawable(result);
					}
				}.execute();
			}

			mTvAppName.setText(campaign.getAppName() + "");
			mTvAppDesc.setText(campaign.getAppDesc() + "");
			mTvCta.setText(campaign.getAdCall());
			nativeHandle.registerView(mRl_Root, campaign);
		}
	}

}
