package com.mobvista.sdk.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mobvista.msdk.MobVistaConstans;
import com.mobvista.msdk.MobVistaSDK;
import com.mobvista.msdk.out.Campaign;
import com.mobvista.msdk.out.Frame;
import com.mobvista.msdk.out.MobVistaSDKFactory;
import com.mobvista.msdk.out.MvNativeHandler;
import com.mobvista.msdk.out.MvNativeHandler.NativeAdListener;
import com.mobvista.msdk.out.MvNativeHandler.Template;
import com.mobvista.sdk.demo.util.ImageLoadTask;
import com.mobvista.sdk.demo.view.StarLevelLayoutView;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * native displayfeedsImage
 *
 */
public class FeedsImageActivity extends BaseActivity {
	private static final String TAG = FeedsImageActivity.class.getName();

	private static final String UNIT_ID = "493";
	private LinearLayout mLl_Root;
	private ImageView mIvIcon;
	private ImageView mIvImage;
	private TextView mTvAppName;
	private TextView mTvAppDesc;
	private TextView mTvCta;
	private StarLevelLayoutView mStarLayout;
	private MvNativeHandler nativeHandle;
	private ProgressBar mProgressBar;

	@Override
	public int getResLayoutId() {
		return R.layout.mobvista_native_feeds_image;
	}

	@Override
	public void initView() {
		mIvIcon = (ImageView) findViewById(R.id.mobvista_feeds_icon);
		mIvImage = (ImageView) findViewById(R.id.mobvista_feeds_image);
		mTvAppName = (TextView) findViewById(R.id.mobvista_feeds_app_name);
		mTvCta = (TextView) findViewById(R.id.mobvista_feeds_tv_cta);
		mTvAppDesc = (TextView) findViewById(R.id.mobvista_feeds_app_desc);
		mLl_Root = (LinearLayout) findViewById(R.id.mobvista_feeds_ll_root);
		mStarLayout = (StarLevelLayoutView) findViewById(R.id.mobvista_feeds_star);
		mProgressBar = (ProgressBar) findViewById(R.id.mobvista_feeds_progress);
	}

	@Override
	public void initData() {
		showLoadding();
		loadNative();
	}

	@Override
	public void setListener() {

	}

	private void showLoadding() {
		mProgressBar.setVisibility(View.VISIBLE);
		mLl_Root.setVisibility(View.GONE);
	}

	private void hideLoadding() {
		mProgressBar.setVisibility(View.GONE);
		mLl_Root.setVisibility(View.VISIBLE);
	}

	public void preloadNative() {

		MobVistaSDK sdk = MobVistaSDKFactory.getMobVistaSDK();
		Map<String, Object> preloadMap = new HashMap<String, Object>();
		preloadMap.put(MobVistaConstans.PROPERTIES_LAYOUT_TYPE, MobVistaConstans.LAYOUT_NATIVE);
		preloadMap.put(MobVistaConstans.PROPERTIES_UNIT_ID, UNIT_ID);

		List<Template> list = new ArrayList<Template>();
		list.add(new Template(MobVistaConstans.TEMPLATE_BIG_IMG, 1));
		preloadMap.put(MobVistaConstans.NATIVE_INFO, MvNativeHandler.getTemplateString(list));
		sdk.preload(preloadMap);

	}

	public void loadNative() {
		Map<String, Object> properties = MvNativeHandler.getNativeProperties(UNIT_ID);
		nativeHandle = new MvNativeHandler(properties, this);
		nativeHandle.addTemplate(new Template(MobVistaConstans.TEMPLATE_BIG_IMG, 1));
		nativeHandle.setAdListener(new NativeAdListener() {

			@Override
			public void onAdLoaded(List<Campaign> campaigns, int template) {
				hideLoadding();
				fillFeedsImageLayout(campaigns);
				preloadNative();
			}

			@Override
			public void onAdLoadError(String message) {
				Log.e(TAG, "onAdLoadError:" + message);
			}

			@Override
			public void onAdFramesLoaded(List<Frame> list) {

			}

			@Override
			public void onAdClick(Campaign campaign) {
				Log.e(TAG, "onAdClick");
			}
		});
		nativeHandle.load();
	}

	protected void fillFeedsImageLayout(List<Campaign> campaigns) {
		if (campaigns != null && campaigns.size() > 0) {
			Campaign campaign = campaigns.get(0);
			if (!TextUtils.isEmpty(campaign.getIconUrl())) {
				new ImageLoadTask(campaign.getIconUrl()) {

					@Override
					public void onRecived(Drawable result) {
						mIvIcon.setImageDrawable(result);
					}
				}.execute();
			}
			if (!TextUtils.isEmpty(campaign.getImageUrl())) {
				new ImageLoadTask(campaign.getImageUrl()) {

					@Override
					public void onRecived(Drawable result) {
						mIvImage.setImageDrawable(result);
					}
				}.execute();
			}
			mTvAppName.setText(campaign.getAppName() + "");
			mTvAppDesc.setText(campaign.getAppDesc() + "");
			mTvCta.setText(campaign.getAdCall());
			int rating = (int) campaign.getRating();
			mStarLayout.setRating(rating);
			nativeHandle.registerView(mLl_Root, campaign);
		}
	}

}
