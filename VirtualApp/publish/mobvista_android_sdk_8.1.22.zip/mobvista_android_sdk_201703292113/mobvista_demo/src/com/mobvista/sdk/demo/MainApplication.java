package com.mobvista.sdk.demo;

import java.util.Map;

import android.app.Application;
import android.content.res.Configuration;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;

import com.mobvista.msdk.MobVistaConstans;
import com.mobvista.msdk.MobVistaSDK;
import com.mobvista.msdk.out.MobVistaSDKFactory;

public class MainApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		Log.i("demo", "application oncreate");
		// init sdk
		MobVistaSDK sdk = MobVistaSDKFactory.getMobVistaSDK();
		// test appId and appKey
		String appId = "24282";
		String appKey = "7c22942b749fe6a6e361b675e96b3ee9";
		Map<String, String> map = sdk.getMVConfigurationMap(appId, appKey);

		// if you modify applicationId, please add the following attributes,
		// otherwise it will crash
		// map.put(MobVistaConstans.PACKAGE_NAME_MANIFEST, "your AndroidManifest
		// package value");
		sdk.init(map, this);
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		DisplayMetrics dm = this.getBaseContext().getResources().getDisplayMetrics();
		this.getBaseContext().getResources().updateConfiguration(newConfig, dm);
	}

}
