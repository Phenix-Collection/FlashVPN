package com.mobvista.sdk.demo;

import com.mobvista.sdk.demo.util.SystemBarTintManager;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

/**
 * all Activity extends base class
 *
 */
public abstract class BaseActivity extends FragmentActivity {
	
	
	
	@SuppressLint("ResourceAsColor")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(getResLayoutId());
		initView();
		initData();
		setListener();
		initWindow();

	}

	private void initWindow() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			SystemBarTintManager tintManager = new SystemBarTintManager(this);
			tintManager.setStatusBarTintColor(getResources().getColor(R.color.mobvista_demo_blue));
			tintManager.setStatusBarTintEnabled(true);
			tintManager.setNavigationBarTintColor(getResources().getColor(R.color.mobvista_demo_blue));
			tintManager.setNavigationBarTintEnabled(true);
		}
	}



	public abstract int getResLayoutId();

	public abstract void initView();

	public abstract void initData();

	public abstract void setListener();

}
