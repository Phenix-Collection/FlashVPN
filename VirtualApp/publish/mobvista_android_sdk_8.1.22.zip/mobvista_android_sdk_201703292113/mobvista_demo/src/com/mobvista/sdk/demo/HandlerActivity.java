package com.mobvista.sdk.demo;

import java.util.HashMap;
import java.util.Map;

import com.mobvista.msdk.MobVistaConstans;
import com.mobvista.msdk.MobVistaSDK;
import com.mobvista.msdk.out.MobVistaSDKFactory;
import com.mobvista.msdk.out.MvWallHandler;
import com.mobvista.sdk.demo.view.CommonTitleLayout;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

public class HandlerActivity extends BaseActivity implements OnClickListener {
	private static final String TAG = HandlerActivity.class.getName();
	private ViewGroup nat;
	private MvWallHandler mvHandler;
	private Button btn_pre, btn_intent;
	private CommonTitleLayout mTitleLayout;
	private Map<String, Object> properties;
	public final String mAppWallUnitId = "496";

	@Override
	public int getResLayoutId() {
		return R.layout.mobvista_demo_atv_appwall;
	}

	@Override
	public void initView() {
		nat = (ViewGroup) findViewById(R.id.nat);
		btn_pre = (Button) findViewById(R.id.btn_preappwall);
		btn_intent = (Button) findViewById(R.id.btn_intent);
		mTitleLayout = (CommonTitleLayout) findViewById(R.id.mobvista_demo_common_title_layout);
	}

	@Override
	public void initData() {
		mTitleLayout.setTitleText("AppWall");
		loadHandler();
	}

	@Override
	public void setListener() {
		btn_intent.setOnClickListener(this);
		btn_pre.setOnClickListener(this);
	}

	/**
	 * Choose a way you can
	 */
	private void setAppWallTitleLogo() {
		// 1.use bitmap as the logo
		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
		properties.put(MobVistaConstans.PROPERTIES_WALL_TITLE_LOGO, bitmap);
		// 2.user drawable resId as the logo
		properties.put(MobVistaConstans.PROPERTIES_WALL_TITLE_LOGO_ID, R.drawable.ic_launcher);
	}

	/**
	 * Choose a way you can
	 */
	private void setAppWallTitleBackgroud() {

		// 1.use bitmap as the appwall title
		Bitmap titleBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.customer_bg);
		properties.put(MobVistaConstans.PROPERTIES_WALL_TITLE_BACKGROUND, titleBitmap);
		// 2.use color resId as the appwall title
		properties.put(MobVistaConstans.PROPERTIES_WALL_TITLE_BACKGROUND_COLOR, R.color.mobvista_green);
		// 3.use drawable resid as the appwall title
		properties.put(MobVistaConstans.PROPERTIES_WALL_TITLE_BACKGROUND_ID, R.drawable.ic_launcher);

	}

	private void setAppWallMainBackgroudColor() {
		// wall main background must be color
		properties.put(MobVistaConstans.PROPERTIES_WALL_MAIN_BACKGROUND_ID, R.color.mobvista_bg_main);
	}

	private void setAppWallTabBackgroud() {
		// wall tab background must be color
		properties.put(MobVistaConstans.PROPERTIES_WALL_TAB_BACKGROUND_ID, R.color.mobvista_bg_main);
	}

	private void setAppWallTabIndicateLineBackgroudColor() {
		// wall tab indicater line must be color
		properties.put(MobVistaConstans.PROPERTIES_WALL_TAB_INDICATE_LINE_BACKGROUND_ID,
				R.color.mobvista_wall_tab_line);
	}

	private void setAppWallButtonBackgroudColor() {
		// wall button color must be drawable
		properties.put(MobVistaConstans.PROPERTIES_WALL_BUTTON_BACKGROUND_ID, R.drawable.mobvista_shape_btn);
	}

	private void setAppWallLoaddingResId() {
		// wall loadding view
		properties.put(MobVistaConstans.PROPERTIES_WALL_LOAD_ID, R.layout.mobvista_demo_wall_click_loading);
	}

	private void setAppWallStatusColor() {
		properties.put(MobVistaConstans.PROPERTIES_WALL_STATUS_COLOR, R.color.mobvista_green);
	}

	private void setAppWallNavigationColor() {
		properties.put(MobVistaConstans.PROPERTIES_WALL_NAVIGATION_COLOR, R.color.mobvista_green);
	}

	private void setAppWallTabColorByHexColorCode() {
		// set the wall tab color of selected and unselected text by hex color
		// codes
		properties.put(MobVistaConstans.PROPERTIES_WALL_TAB_SELECTED_TEXT_COLOR, "#ff7900");
		properties.put(MobVistaConstans.PROPERTIES_WALL_TAB_UNSELECTED_TEXT_COLOR, "#ffaa00");

	}

	@SuppressLint("InflateParams")
	public void loadHandler() {
		properties = MvWallHandler.getWallProperties(mAppWallUnitId);
		// setAppWallTitleLogo();
		// setAppWallTitleBackgroud();
		// setAppWallButtonBackgroudColor();
		// setAppWallLoaddingResId();
		// setAppWallMainBackgroudColor();
		// setAppWallTabBackgroud();
		// setAppWallTabIndicateLineBackgroudColor();
		// setAppWallStatusColor();
		// setAppWallNavigationColor();
		// setAppWallTabColorByHexColorCode();
		// nat for the click event viewGroup
		mvHandler = new MvWallHandler(properties, this, nat);
		// customer entry layout begin The part of the code can not
		View view = getLayoutInflater().inflate(R.layout.customer_entry, null);
		view.findViewById(R.id.imageview).setTag(MobVistaConstans.WALL_ENTRY_ID_IMAGEVIEW_IMAGE);
		view.findViewById(R.id.newtip_area).setTag(MobVistaConstans.WALL_ENTRY_ID_VIEWGROUP_NEWTIP);
		mvHandler.setHandlerCustomerLayout(view);
		// customer entry layout end */
		mvHandler.load();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_intent:
			openWall();
			break;

		case R.id.btn_preappwall:
			preloadWall();
			break;
		}
	}

	/**
	 * Preloading the appwall can improve the revenue for you.
	 */
	public void preloadWall() {
		MobVistaSDK sdk = MobVistaSDKFactory.getMobVistaSDK();
		Map<String, Object> preloadMap = new HashMap<String, Object>();
		preloadMap.put(MobVistaConstans.PROPERTIES_LAYOUT_TYPE, MobVistaConstans.LAYOUT_APPWALL);
		preloadMap.put(MobVistaConstans.PROPERTIES_UNIT_ID, mAppWallUnitId);
		sdk.preload(preloadMap);
	}

	/**
	 * open the appwall via intent
	 */
	public void openWall() {
		try {
			Map<String, Object> properties = MvWallHandler.getWallProperties(mAppWallUnitId);
			MvWallHandler mvHandler = new MvWallHandler(properties, HandlerActivity.this);
			mvHandler.startWall();
		} catch (Exception e) {
			Log.e("MVActivity", "", e);
		}
	}

}
