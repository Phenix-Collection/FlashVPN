package com.mobvista.sdk.demo;

import java.util.ArrayList;
import java.util.List;

import com.mobvista.sdk.demo.adapter.CommonAdapter;
import com.mobvista.sdk.demo.adapter.ViewHolder;
import com.mobvista.sdk.demo.bean.AdStyleInfoBean;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class HomeActivity extends BaseActivity {

	private static final String TAG = HomeActivity.class.getName();
	private static final int POSITION_NATIVE = 0;
	private static final int POSITION_APPWALL = 1;
	private static final int POSITION_REWARDVIDEO = 2;
	private static final int POSITION_FEEDSVIDEO = 3;
	private static final int POSITION_OFFERWALL = 4;
	private static final int POSITION_INTERSTITIAL = 5;

	private ListView mLvAdList;

	@Override
	public int getResLayoutId() {
		return R.layout.mobvista_demo_atv_home;
	}

	@Override
	public void initView() {

		mLvAdList = (ListView) findViewById(R.id.mobvista_demo_lv_ad_list);
	}

	@Override
	public void initData() {
		List<AdStyleInfoBean> adStyleLists = new ArrayList<AdStyleInfoBean>();
		AdStyleInfoBean nativeStyle = new AdStyleInfoBean("Native", R.drawable.mobvista_demo_ad_native,
				R.drawable.mobvista_demo_icon_native);
		AdStyleInfoBean appWallStyle = new AdStyleInfoBean("APPWALL", R.drawable.mobvista_demo_ad_appwall,
				R.drawable.mobvista_demo_icon_appwall);
		AdStyleInfoBean rewardStyle = new AdStyleInfoBean("RewardVideo", R.drawable.mobvista_demo_ad_reward,
				R.drawable.mobvista_demo_icon_reward);
		AdStyleInfoBean feedsStyle = new AdStyleInfoBean("FeedsVideo", R.drawable.mobvista_demo_ad_feedsvideo,
				R.drawable.mobvista_demo_icon_feed_video);
		AdStyleInfoBean offerwallStyle = new AdStyleInfoBean("offerWall", R.drawable.mobvista_demo_ad_offerwal,
				R.drawable.mobvista_demo_icon_offerwall);
		AdStyleInfoBean intersititialStyle = new AdStyleInfoBean("interstitial", R.drawable.mobvista_demo_ad_interstitial,
				R.drawable.mobvista_demo_icon_intertitial);
		adStyleLists.add(nativeStyle);
		adStyleLists.add(appWallStyle);
		adStyleLists.add(rewardStyle);
		adStyleLists.add(feedsStyle);
		adStyleLists.add(offerwallStyle);
		adStyleLists.add(intersititialStyle);
		CommonAdapter<AdStyleInfoBean> adapter = new CommonAdapter<AdStyleInfoBean>(adStyleLists,
				R.layout.mobvista_demo_item_ad_style, this) {

			@Override
			public void convert(ViewHolder helper, AdStyleInfoBean item) {
				helper.setText(R.id.mobvista_demo_item_tv_ad_name, item.getAdStyleName());
				helper.setImageResource(R.id.mobvista_demo_item_iv_big, item.getAdImageResId());
				helper.setImageResource(R.id.mobvista_demo_item_iv_icon, item.getAdIconResId());
			}
		};
		mLvAdList.setAdapter(adapter);
	}

	@Override
	public void setListener() {
		mLvAdList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent intent = null;
				switch (position) {
				case POSITION_NATIVE:
					intent = new Intent(HomeActivity.this, NativeChoiceActivity.class);
					startActivity(intent);
					break;
				case POSITION_APPWALL:
					intent = new Intent(HomeActivity.this, HandlerActivity.class);
					startActivity(intent);
					break;
				case POSITION_REWARDVIDEO:
					intent = new Intent(HomeActivity.this, RewardActivity.class);
					startActivity(intent);
					break;
				case POSITION_FEEDSVIDEO:
					intent = new Intent(HomeActivity.this, FeedsActivity.class);
					startActivity(intent);
					break;
				case POSITION_OFFERWALL:
					intent = new Intent(HomeActivity.this, OfferWallActivity.class);
					startActivity(intent);
					break;
				case POSITION_INTERSTITIAL:
					intent = new Intent(HomeActivity.this, InterstitialActivity.class);
					startActivity(intent);
					break;

				}
			}
		});
	}


}
